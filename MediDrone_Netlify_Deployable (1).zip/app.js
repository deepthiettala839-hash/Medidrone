const state = {
  page: "emergency",
  patient: null,
  location: null,
  cart: [],
  otp: null
};

const supplies = [
  ["💊","Order medicines","Prescription-based orders",350],
  ["🧰","First aid kit","Emergency essentials",250],
  ["🧼","Sanitary products","Personal care",120],
  ["🧪","Diagnostics kit","Basic diagnostic supplies",300],
  ["🧫","Sample test kit","Collection supplies",180],
  ["💉","Injections","Clinician-approved requests",220],
  ["👨‍⚕️","Doctor at home","Request a home visit",700],
  ["👩‍⚕️","Nurse at home","Request nursing support",450],
  ["📅","Doctor appointment","Find an appointment",0],
  ["🚑","Ambulance booking","Request transport",1200],
  ["🏥","Hospital availability","AI-assisted discovery",0],
  ["🏥","My hospital","Check a preferred hospital",0],
  ["🩹","Bandages","Dressings and bandages",90],
  ["♿","Wheelchair","Mobility support",0],
  ["🧴","Antiseptic supplies","Cleaning and care",140],
  ["😷","Masks","Protective masks",80],
  ["🫁","Oxygen supply","Verified supplier request",900],
  ["🩸","Blood storage","Inventory monitoring",0],
  ["🌡️","Thermometer","Digital thermometer",160],
  ["🫁","Ventilation supply","Hospital equipment request",0]
];

const hospitals = [
  ["City Care Hospital","3.2 km","Emergency available","9 min"],
  ["General Medical Centre","5.1 km","Emergency available","14 min"],
  ["Community Hospital","7.4 km","Limited emergency","18 min"]
];

const $ = (id) => document.getElementById(id);

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2800);
}

function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  const target = $(page);
  if (target) target.classList.add("active");
  const tab = document.querySelector(`.tab[data-page="${page}"]`);
  if (tab) tab.classList.add("active");
  state.page = page;
  window.scrollTo({top: 0, behavior: "smooth"});
}

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => showPage(tab.dataset.page));
});
document.querySelectorAll("[data-page-jump]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.pageJump));
});

$("patientForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  state.patient = {
    name: $("patientName").value.trim(),
    age: Number($("patientAge").value),
    gender: $("patientGender").value,
    mobile: $("patientMobile").value.trim(),
    location: state.location
  };

  try {
    const response = await fetch("/.netlify/functions/patients", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(state.patient)
    });
    if (!response.ok) throw new Error("function unavailable");
    const data = await response.json();
    $("registrationResult").textContent = `Registered successfully. Patient ID: ${data.patientId}`;
  } catch {
    const demoId = "MD-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    $("registrationResult").textContent = `Demo registration complete. Patient ID: ${demoId}`;
  }
  $("registrationResult").classList.remove("hidden");
  showToast("Patient registration saved.");
});

document.querySelectorAll(".emergency-action").forEach(btn => {
  btn.addEventListener("click", () => requestEmergency(btn.dataset.emergency));
});
$("sosButton").addEventListener("click", () => requestEmergency("SOS Emergency"));

async function requestEmergency(type) {
  if (!state.patient) {
    showToast("Please register the patient first.");
    return;
  }
  try {
    const response = await fetch("/.netlify/functions/emergency", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        type,
        patient: state.patient,
        location: state.location
      })
    });
    if (!response.ok) throw new Error("function unavailable");
    const data = await response.json();
    showToast(`${type}: ${data.priority} priority. Human dispatch approval required.`);
  } catch {
    showToast(`${type} alert created in demo mode. Human dispatch approval required.`);
  }
}

$("locationButton").addEventListener("click", () => {
  if (!navigator.geolocation) {
    showToast("GPS is not supported by this browser.");
    return;
  }
  navigator.geolocation.getCurrentPosition(
    pos => {
      state.location = {
        latitude: Number(pos.coords.latitude.toFixed(6)),
        longitude: Number(pos.coords.longitude.toFixed(6))
      };
      $("locationText").textContent = `${state.location.latitude}, ${state.location.longitude}`;
      if (state.patient) state.patient.location = state.location;
      if (!$("deliveryLocation").value) $("deliveryLocation").value = `${state.location.latitude}, ${state.location.longitude}`;
      showToast("GPS location added.");
    },
    () => showToast("Location permission was not granted.")
  );
});

$("trackButton").addEventListener("click", () => {
  showPage("tracking");
  startTrackingDemo();
});
$("closeTracking").addEventListener("click", () => showPage("emergency"));

function startTrackingDemo() {
  let eta = 12;
  $("trackingStatus").textContent = "En route";
  $("droneStatus").textContent = "En route • MD-204";
  const timer = setInterval(() => {
    eta--;
    $("eta").textContent = `${Math.max(eta, 1)} min`;
    if (eta <= 0) {
      clearInterval(timer);
      $("trackingStatus").textContent = "Arrived";
      $("droneStatus").textContent = "Arrived • MD-204";
    }
  }, 3000);
}

function renderSupplies(list = supplies) {
  $("supplyGrid").innerHTML = list.map((item, index) => `
    <button class="supply-item" data-index="${supplies.indexOf(item)}">
      <span class="emoji">${item[0]}</span>
      <b>${item[1]}</b>
      <small>${item[2]}</small>
    </button>
  `).join("");
  document.querySelectorAll(".supply-item").forEach(btn => {
    btn.addEventListener("click", () => addToCart(Number(btn.dataset.index)));
  });
}

function addToCart(index) {
  const item = supplies[index];
  if (item[3] === 0) {
    showToast(`${item[1]} selected. A service request can be created in production.`);
    return;
  }
  state.cart.push({name:item[1], price:item[3]});
  renderSummary();
  showToast(`${item[1]} added to order.`);
}

$("supplySearch").addEventListener("input", (e) => {
  const q = e.target.value.toLowerCase();
  renderSupplies(supplies.filter(x => x[1].toLowerCase().includes(q) || x[2].toLowerCase().includes(q)));
});

function renderHospitals() {
  $("hospitalList").innerHTML = hospitals.map(h => `
    <div class="hospital">
      <span>🏥</span>
      <div><b>${h[0]}</b><div class="muted">${h[1]} • ETA ${h[3]}</div></div>
      <span class="badge">${h[2]}</span>
    </div>
  `).join("");
}
$("hospitalRefresh").addEventListener("click", () => {
  renderHospitals();
  showToast("Demo hospital availability refreshed.");
});

document.querySelectorAll(".ai-item").forEach(btn => {
  btn.addEventListener("click", () => {
    const type = btn.dataset.ai;
    const messages = {
      precautions: "General reminder: follow your clinician's instructions, keep medicines labeled, and seek urgent medical care for severe or rapidly worsening symptoms.",
      timings: "Medicine timing should come from the verified prescription. MediDrone can display reminders but should not invent or change dosage instructions.",
      doctor: "A production version can play a clinician-approved voice message in the patient's selected language.",
      assistant: "I am a non-diagnostic AI assistant. I can explain verified healthcare information, help navigate services, and connect you to appropriate human professionals."
    };
    $("aiResponse").textContent = messages[type];
  });
});

let recognition = null;
$("micButton").addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    $("voiceOutput").textContent = "Speech recognition is not supported in this browser. Try a compatible mobile browser or integrate a cloud speech service in production.";
    return;
  }
  if (recognition) recognition.stop();
  recognition = new SpeechRecognition();
  recognition.lang = $("fromLang").value;
  recognition.interimResults = false;
  recognition.onstart = () => $("voiceOutput").textContent = "Listening...";
  recognition.onresult = e => {
    const text = e.results[0][0].transcript;
    $("voiceOutput").textContent = `Heard: "${text}" • Translation service can process this text in production.`;
  };
  recognition.onerror = () => $("voiceOutput").textContent = "Voice capture failed or permission was denied.";
  recognition.start();
});

function renderSummary() {
  const box = $("orderSummary");
  if (!state.cart.length) {
    box.innerHTML = '<p class="muted">No items selected.</p>';
    $("total").textContent = "₹0";
    return;
  }
  box.innerHTML = state.cart.map((x, i) => `
    <div class="order-line"><span>${x.name}</span><b>₹${x.price}</b></div>
  `).join("");
  const total = state.cart.reduce((sum,x) => sum + x.price, 0);
  $("total").textContent = `₹${total}`;
}

$("sendOtp").addEventListener("click", () => {
  state.otp = String(Math.floor(100000 + Math.random() * 900000));
  showToast(`Demo OTP: ${state.otp}`);
});

$("confirmOrder").addEventListener("click", async () => {
  if (!state.cart.length) {
    showToast("Add at least one paid item first.");
    return;
  }
  if (!$("deliveryLocation").value.trim()) {
    showToast("Add a delivery location first.");
    return;
  }
  if (!state.otp || $("otp").value.trim() !== state.otp) {
    showToast("Enter the demo OTP shown after 'Send demo OTP'.");
    return;
  }

  const payload = {
    items: state.cart,
    location: $("deliveryLocation").value.trim(),
    paymentMethod: $("paymentMethod").value,
    patient: state.patient
  };

  try {
    const response = await fetch("/.netlify/functions/orders", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error("function unavailable");
    const data = await response.json();
    $("orderResult").textContent = `Order confirmed: ${data.orderId}`;
  } catch {
    $("orderResult").textContent = `Demo order confirmed: MD-ORD-${Date.now().toString().slice(-6)}`;
  }
  $("orderResult").classList.remove("hidden");
  showToast("Order confirmed.");
});

renderSupplies();
renderHospitals();
renderSummary();
