exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const body = JSON.parse(event.body || "{}");
    const type = body.type || "Emergency";

    // Prototype decision-support logic only.
    // Production dispatch requires verified integrations and human/EMS authorization.
    const priority = type === "SOS Emergency" ? "CRITICAL" : "HIGH";

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        priority,
        recommendedResource: type === "Medical Drone" ? "DRONE" : "AMBULANCE",
        humanReviewRequired: true,
        emergencyId: "MD-EM-" + Date.now().toString().slice(-7)
      })
    };
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid emergency request." }) };
  }
};
