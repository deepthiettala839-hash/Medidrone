exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const patient = JSON.parse(event.body || "{}");

    if (!patient.name || !patient.age || !patient.mobile) {
      return { statusCode: 400, body: JSON.stringify({ error: "Name, age and mobile are required." }) };
    }

    // Prototype only: Netlify Functions are stateless.
    // Connect this function to MongoDB Atlas/Supabase/etc. for persistent storage.
    const patientId = "MD-" + Math.random().toString(36).slice(2, 9).toUpperCase();

    return {
      statusCode: 201,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        patientId,
        message: "Patient registration accepted by prototype API."
      })
    };
  } catch (error) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid request." }) };
  }
};
