exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const order = JSON.parse(event.body || "{}");

    if (!Array.isArray(order.items) || !order.items.length || !order.location) {
      return { statusCode: 400, body: JSON.stringify({ error: "Items and location are required." }) };
    }

    // Prototype only. Do not process or store raw banking credentials here.
    const orderId = "MD-ORD-" + Date.now().toString().slice(-8);

    return {
      statusCode: 201,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        orderId,
        status: "CONFIRMED_DEMO",
        message: "Order accepted by prototype API."
      })
    };
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid order request." }) };
  }
};
