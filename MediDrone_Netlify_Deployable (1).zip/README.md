# MediDrone AI Healthcare — Netlify Prototype

This is a deployable web prototype of the MediDrone concept.

## Included

- Futuristic responsive healthcare dashboard
- Patient registration
- Emergency alerts
- Ambulance / drone / blood / emergency kit actions
- Browser GPS
- Medical supplies and services catalog
- Demo hospital availability
- AI-care interface
- Browser voice capture
- Payment/order flow with demo OTP
- Demo drone tracking
- Netlify Functions for registration, emergency and orders

## Deploy to Netlify

### Option A — Drag and drop

1. Unzip this project.
2. Open Netlify and create a new site.
3. Drag the entire project folder into the Netlify deploy area.
4. Netlify reads `netlify.toml` and deploys the static site plus Functions.

### Option B — Git

1. Put this folder into a GitHub repository.
2. In Netlify choose Add new project / Import from Git.
3. Select the repository.
4. Build command: leave blank.
5. Publish directory: `.`
6. Deploy.

## Important production note

This package is a prototype. Netlify Functions are stateless, so the included endpoints do not permanently store patient records or orders.

For a real healthcare deployment, connect the functions to a managed database such as MongoDB Atlas or another appropriate HIPAA/GDPR/local-regulation-compatible service, depending on jurisdiction and requirements.

You should also add:

- Secure authentication and role-based access
- OTP provider
- Regulated payment gateway
- Hospital/provider APIs
- Verified pharmacy/inventory APIs
- Blood-bank integrations
- Ambulance/EMS integrations
- Maps and routing API
- Weather and drone telemetry services
- Cloud speech-to-text / translation / text-to-speech
- AI service with human review and audit logging
- Encryption and secrets management
- Consent, privacy, retention and deletion controls
- Regulatory and clinical safety review
- Aviation/drone authorization and operator integrations

Never store payment PINs, banking passwords, or raw card credentials in MediDrone.

AI must be treated as decision support. It should not independently diagnose patients, prescribe medication, or dispatch real-world emergency resources without the required human/authorized workflow.
